// api/index.ts
import app from "../server/index"; // Import your Express app
export default app;